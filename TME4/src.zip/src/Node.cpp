// -*- explicit-buffer-name: "Node.cpp<M1-MOBJ/4-5>" -*-

#include  <limits>
#include  "Node.h"
#include  "Term.h"
#include  "Net.h"
#include  "Instance.h"
#include  "Cell.h"

namespace Netlist {

  using namespace std;


  const size_t  Node::noid = numeric_limits<size_t>::max();


  Node::Node ( Term* term, size_t id  )
    : id_      (id)
    , term_    (term)
    , position_()
  {}


  Node::~Node ()
  {
    if (getNet()) getNet()->remove( this );
  }


  inline Net* Node::getNet () const { return term_->getNet(); }

// Node::toXml() Ã  Ã©crire ici.

  void Node::toXml(std::ostream& o){
    if(term_->isInternal())
      o << ++indent <<"<node term=\"" << term_->getName() << "\" instance=\"" <<    term_->getInstance()->getName() << "\" id=\"" << id_ << "\" x=\"" << position_.getX() << "\" y=\"" << position_.getY() << "\"/>" << --indent << std::endl;
    else if(term_->isExternal())
      o << ++indent <<"<node term=\"" << term_->getName() << "\" id=\"" << id_ << "\" x=\"" << position_.getX() << "\" y=\"" << position_.getY() << "\"/>" << --indent << std::endl;
  }

  bool Node::fromXml(Net* n, xmlTextReaderPtr TxtR){
    std::string term = xmlCharToString(     xmlTextReaderGetAttribute(   TxtR, (const xmlChar*) "term"     )     );
    std::string id_str = xmlCharToString   (xmlTextReaderGetAttribute(  TxtR, (const xmlChar*) "id")     );
    std::string x_str = xmlCharToString(    xmlTextReaderGetAttribute(   TxtR, (const xmlChar*) "x")     );
    std::string y_str = xmlCharToString(    xmlTextReaderGetAttribute(   TxtR, (const xmlChar*) "y")     );
    std::string instance = xmlCharToString( xmlTextReaderGetAttribute( TxtR, (const xmlChar*)"instance" ) );

    if(term.empty() or id_str.empty() or x_str.empty() or y_str.empty()){
      return false;
    }

    if(!instance.empty()){
      n->getCell()->getInstance(instance)->getTerm(term)->getNode()->setId(std::atoi(id_str.c_str()));
      n->getCell()->getInstance(instance)->getTerm(term)->setPosition(std::atoi(x_str.c_str()),std::atoi(y_str.c_str()));
      n->getCell()->getInstance(instance)->connect(term,n);
    }else{
      n->getCell()->getTerm(term)->getNode()->setId(std::atoi(id_str.c_str()));
      n->getCell()->connect(term,n);
    }
                
    return true;
  }


}  // Netlist namespace.